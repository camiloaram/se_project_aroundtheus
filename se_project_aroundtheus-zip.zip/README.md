Around The U.S

HTML/CSS Responsive Design.

.js and arrays

[Project on Github Pages]
https://camiloaram.github.io/se_project_aroundtheus/

[Video link on Loom]
https://www.loom.com/share/5510f104ed5a47feb082038e1c443f78?sid=6fff92a0-c401-48f4-bf4b-519b2c4c973c
